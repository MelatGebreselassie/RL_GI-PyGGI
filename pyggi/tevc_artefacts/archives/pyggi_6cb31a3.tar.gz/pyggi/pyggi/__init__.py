"""
PYGGI: Python General framework for Genetic Improvement
"""
PYGGI_DIR = './.pyggi/'

def oink():
    '''
    :return: ``'oink oink'``
    :rtype: str
    '''
    return 'oink oink'