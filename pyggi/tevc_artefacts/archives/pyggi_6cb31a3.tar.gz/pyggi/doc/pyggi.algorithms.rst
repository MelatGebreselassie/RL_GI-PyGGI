pyggi.algorithms module
=======================

.. automodule:: pyggi.algorithms
    :members:
    :undoc-members:
    :show-inheritance:
