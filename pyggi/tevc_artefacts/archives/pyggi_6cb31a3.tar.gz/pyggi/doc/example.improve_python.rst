example.improve_python module
=============================

.. automodule:: example.improve_python
    :members:
    :undoc-members:
    :show-inheritance:
