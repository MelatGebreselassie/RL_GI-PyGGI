pyggi
=====

Submodules
----------

.. toctree::
   pyggi.algorithms
   pyggi.atomic_operator
   pyggi.edit
   pyggi.logger
   pyggi.patch
   pyggi.program
   pyggi.test_result

Module contents
---------------

.. automodule:: pyggi
    :members:
    :undoc-members:
    :show-inheritance:
