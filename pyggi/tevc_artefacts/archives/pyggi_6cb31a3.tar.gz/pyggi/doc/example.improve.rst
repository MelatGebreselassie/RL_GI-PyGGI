example.improve module
======================

.. automodule:: example.improve
    :members:
    :undoc-members:
    :show-inheritance:
