pyggi.test_result module
========================

.. automodule:: pyggi.test_result
    :members:
    :undoc-members:
    :show-inheritance:
