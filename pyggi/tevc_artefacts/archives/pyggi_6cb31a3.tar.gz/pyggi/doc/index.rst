.. pyggi documentation master file, created by
   sphinx-quickstart on Fri Dec 15 14:10:50 2017.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

PYGGI
=====

PYGGI stands for Python General framework for Genetic Improvement(GI).

Written & maintained by COINSE KAIST.

* Github: <https://github.com/coinse/pyggi>
* COINSE Lab: <https://coinse.kaist.ac.kr>

What's inside?
--------------

.. toctree::
   :maxdepth: 3

   pyggi package <pyggi>
   examples <example>

Indices and tables
------------------

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
