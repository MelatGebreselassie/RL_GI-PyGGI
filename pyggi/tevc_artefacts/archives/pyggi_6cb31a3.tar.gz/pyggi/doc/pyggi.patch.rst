pyggi.patch module
==================

.. automodule:: pyggi.patch
    :members:
    :undoc-members:
    :show-inheritance:
